Please ignore warning if u get any as windows defender warns yous if you try to run any unpopular softwares 

If the downloaded version has problems you may:
1. Download updated version from https://bit.ly/3MdaFod
2. It will Download on it's Own in your Downloads Folder
3. Right Click the File in your Downloads Folder and then Click Extract
4. Extract it and then Open the Extracted Folder
5. Click the App Named "YTDownlorder"

Now, Steps of the App:
1. Open It
2. It will Take a Little Time so Wait Since it's Slow
3. Put ANY URL of Youtube Video and Press Enter
4. When it's Downloading the Video, the Download Button will Turn to Black/Gray Color
5. When it's Downloaded the Video, Open Downloads Folder and See the Video :D.

If you have any problems please contact Leloush#8013 on discord.

Enjoy ;)